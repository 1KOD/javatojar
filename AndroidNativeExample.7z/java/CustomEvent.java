public interface CustomEvent {
    void onEvent(String value);
}