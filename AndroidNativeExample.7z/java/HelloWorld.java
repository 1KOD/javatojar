import android.os.CountDownTimer;

public class HelloWorld {

	public static int staticDegisken;
	
	public static void setStaticDegisken(int value) 
	{
		staticDegisken = value;
	}

	public static int getStaticDegisken() 
	{
		return staticDegisken;
	}

	public static String getStrStatic(String str) 
	{

		String strAnswer;
		String strHelloDelphi = "Merhaba delphi!";

		if (str.toLowerCase().equals(strHelloDelphi))
			strAnswer = "Merhaba Dünya\n";
		else
			strAnswer = "(Merhaba)\n"+str+"\nBu bir static method";

		return strAnswer;
	}
	
	public String getStrNoStatic(String str) 
	{
		return str + "\n(Bur bir no static method)";
	}
			
	public static void callAnotherMethod(CustomEvent customEvent) 
	{
        		
		new CountDownTimer(10000, 1000) {

			public void onTick(long millisUntilFinished) 
			{
			
			}

			public void onFinish() 
			{
				customEvent.onEvent("test");	
			}
			
		}.start();
    }

}